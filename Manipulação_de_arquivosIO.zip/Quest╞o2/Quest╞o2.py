arquivoEntrada = open("entrada.txt", "r")
juntar = arquivoEntrada.readline()

arquivoEntrada2 = open("entrada2.txt", "r")
juntar2 = arquivoEntrada2.readline()

arquivoEntrada.close()
arquivoEntrada2.close()


conc=juntar+juntar2
      

arquivoSaida = open("saida.txt", "w")

arquivoSaida.write('Concaternação: \n')


for i in conc:
    arquivoSaida.write('%s' % i)



arquivoSaida.close()
