arquivoEntrada = open("entrada.txt", "r",encoding="utf8")
linhas = arquivoEntrada.readline()
arquivoEntrada.close()



for i in linhas:
    linhas=linhas.upper()

       

arquivoSaida = open("saida.txt", "w")

arquivoSaida.write('String Maiuscula: \n')

for i in linhas:
    arquivoSaida.write('%s' % i)



arquivoSaida.close()
