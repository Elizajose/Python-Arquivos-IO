arquivoEntrada = open("entrada.txt", "r")
linhas = arquivoEntrada.readlines()
arquivoEntrada.close()
dic={}
telefone=0
linhas = "Almas"
while linhas!="":
    linhas = input("Digite o seu nome: ")
    if linhas!="":    
        telefone = int(input("Digite seu telefone: "))
        dic[linhas,telefone] = [linhas,telefone]
        
       

arquivoSaida = open("saida.txt", "w")

arquivoSaida.write('Nome----------- Telefone: \n')

for i in dic:
    dic == [linhas,telefone]
    arquivoSaida.write('%s   %d \n' % i)
    
    





arquivoSaida.close()
